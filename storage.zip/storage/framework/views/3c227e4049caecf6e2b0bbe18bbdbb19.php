<?php echo e($slot); ?>

<?php /**PATH D:\BUNKER FRONTEND\bunker_back\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>