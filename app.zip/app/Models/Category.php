<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $fillable = ['name', "description", "img", "created_by"];

    public function subCategories()
    {
        return $this->hasMany(SubCategory::class);
    }
}
