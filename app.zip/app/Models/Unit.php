<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Unit extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'symbol', 'unit_type_id'];

    public function unitType()
    {
        return $this->belongsTo(UnitType::class);
    }

    public function productUnits()
    {
        return $this->hasMany(ProductUnit::class);
    }
}

